import  '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Code from './components/taskCode'

function App() {
  return (
    <div className="d-flex justify-content-center pt-5">
      <Code />
    </div>
  );
}

export default App;
